create extension if not exists pgcrypto;

create table if not exists profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text,
 student_id text unique,
 phone text,
 role text not null default 'student' check(role in ('student','admin')),
 created_at timestamptz not null default now()
);

create table if not exists questions (
 id uuid primary key default gen_random_uuid(),
 course text not null,
 topic text not null,
 difficulty text not null check(difficulty in ('Easy','Medium','Hard')),
 question text not null,
 options jsonb not null,
 answer text not null,
 explanation text not null,
 is_premium boolean not null default true,
 created_at timestamptz not null default now()
);

create table if not exists subscriptions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 package text not null default 'TSU PREMIUM QUESTION BANK',
 amount integer not null default 1000,
 currency text not null default 'NGN',
 status text not null default 'active',
 start_date timestamptz not null default now(),
 expiry_date timestamptz,
 paystack_reference text unique,
 created_at timestamptz not null default now(),
 unique(user_id)
);

create table if not exists payments (
 id uuid primary key default gen_random_uuid(),
 user_id uuid references auth.users(id) on delete set null,
 reference text unique not null,
 amount integer not null,
 currency text not null,
 status text not null,
 package text not null,
 paid_at timestamptz,
 created_at timestamptz not null default now()
);

alter table profiles enable row level security;
alter table questions enable row level security;
alter table subscriptions enable row level security;
alter table payments enable row level security;

create policy "profiles own read" on profiles for select using (auth.uid()=id);
create policy "free questions readable" on questions for select using (is_premium=false);
create policy "own subscription read" on subscriptions for select using (auth.uid()=user_id);
create policy "own payments read" on payments for select using (auth.uid()=user_id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
 insert into public.profiles(id,full_name,student_id,phone)
 values(new.id,new.raw_user_meta_data->>'full_name',new.raw_user_meta_data->>'student_id',new.raw_user_meta_data->>'phone')
 on conflict(id) do nothing;
 return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

insert into questions(course,topic,difficulty,question,options,answer,explanation,is_premium) values
('TSU-ANS 204','Nucleic acids','Easy','Which molecule carries genetic information in most living organisms?','["DNA","Glucose","Lipid","Starch"]','A','DNA stores hereditary information.',false),
('TSU-ANS 204','Proteins','Easy','The bond joining two amino acids is called a...','["Peptide bond","Glycosidic bond","Ester bond","Phosphodiester bond"]','A','A peptide bond links amino acids in proteins.',false),
('AGR 204','Animal production','Easy','Which animal is a ruminant?','["Cattle","Pig","Chicken","Rabbit"]','A','Cattle possess a rumen and other specialized stomach compartments.',false),
('TSU CPS 204','Plant tissue culture','Easy','Totipotency means a plant cell can potentially...','["Regenerate into a whole plant","Only form roots","Only produce DNA","Become an animal cell"]','A','Plant cells can regenerate into complete plants under suitable conditions.',false)
on conflict do nothing;
