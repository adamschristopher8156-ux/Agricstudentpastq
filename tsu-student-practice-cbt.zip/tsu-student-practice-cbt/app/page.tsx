import Link from "next/link";
export default function Home(){
 return <><nav className="nav"><div className="brand">TSU Student Practice CBT</div><div className="navlinks"><Link href="/courses">Courses</Link><Link href="/login">Login</Link><Link href="/signup">Sign up</Link></div></nav>
 <main className="container"><section className="hero"><h1>Practice smarter. Enter the CBT room prepared.</h1><p>Study and practise TSU courses with randomized questions, explanations, scoring, progress tracking and premium access.</p><Link className="btn secondary" href="/courses">Start Practising</Link></section>
 <h2>Available Courses</h2><div className="grid">
 {["TSU-ANS 204 – Introduction to Biochemistry","AGR 204 – Principles of Animal Production","TSU CPS 204 – Introduction to Agricultural Biotechnology"].map(x=><div className="card" key={x}><h3>{x}</h3><p className="muted">MCQs • Explanations • Practice mode</p><Link className="btn" href="/practice">Practice</Link></div>)}</div>
 <div className="card" style={{marginTop:20}}><h2>Premium Question Bank</h2><p>One package, all three courses, for exactly ₦1,000.</p><div className="price">₦1,000</div><Link className="btn" href="/premium">Get Premium</Link></div></main><footer className="footer">TSU Student Practice CBT</footer></>
}