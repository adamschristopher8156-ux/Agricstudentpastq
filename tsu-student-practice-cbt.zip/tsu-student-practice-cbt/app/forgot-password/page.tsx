 "use client";
import {useState} from "react";
import {createClient} from "@supabase/supabase-js";
export default function Forgot(){const [m,setM]=useState("");
async function submit(e:React.FormEvent<HTMLFormElement>){e.preventDefault();const email=String(new FormData(e.currentTarget).get("email"));const supabase=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);const {error}=await supabase.auth.resetPasswordForEmail(email,{redirectTo:`${location.origin}/reset-password`});setM(error?.message||"Password reset instructions sent.");}
return <main className="container"><form className="form" onSubmit={submit}><h1>Reset password</h1><label>Email</label><input name="email" type="email" required/><button className="btn">Send reset link</button>{m&&<div className="notice">{m}</div>}</form></main>}