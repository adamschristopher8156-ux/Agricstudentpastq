 "use client";
import {useState} from "react";
import {createClient} from "@supabase/supabase-js";
export default function Reset(){const [m,setM]=useState("");
async function submit(e:React.FormEvent<HTMLFormElement>){e.preventDefault();const p=String(new FormData(e.currentTarget).get("password"));const supabase=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);const {error}=await supabase.auth.updateUser({password:p});setM(error?.message||"Password updated.");}
return <main className="container"><form className="form" onSubmit={submit}><h1>New password</h1><label>Password</label><input name="password" type="password" minLength={6} required/><button className="btn">Update password</button>{m&&<div className="notice">{m}</div>}</form></main>}