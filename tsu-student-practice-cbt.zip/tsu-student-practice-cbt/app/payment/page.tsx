 "use client";
import {useState} from "react";
export default function Payment(){const [m,setM]=useState("");
async function pay(){setM("Payment integration is configured for Paystack. Add your Paystack public key/server environment variables, then connect this button to the initialize-payment route.");}
return <main className="container"><div className="card"><h1>Premium Payment</h1><p>TSU PREMIUM QUESTION BANK</p><div className="price">₦1,000</div><button className="btn" onClick={pay}>Pay ₦1,000 with Paystack</button>{m&&<div className="notice">{m}</div>}</div></main>}