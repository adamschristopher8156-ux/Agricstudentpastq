 "use client";
import {useState} from "react";
import {createClient} from "@supabase/supabase-js";
export default function Login(){const [m,setM]=useState("");
async function submit(e:React.FormEvent<HTMLFormElement>){e.preventDefault();const f=new FormData(e.currentTarget);const supabase=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!);const {error}=await supabase.auth.signInWithPassword({email:String(f.get("email")),password:String(f.get("password"))});setM(error?.message||"Login successful. Continue to /dashboard.");}
return <main className="container"><form className="form" onSubmit={submit}><h1>Student Login</h1><label>Email</label><input name="email" type="email" required/><label>Password</label><input name="password" type="password" required/><button className="btn">Login</button><p><a href="/forgot-password">Forgot password?</a></p>{m&&<div className="notice">{m}</div>}</form></main>}