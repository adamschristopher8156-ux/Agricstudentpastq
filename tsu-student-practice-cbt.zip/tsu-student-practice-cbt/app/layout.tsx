import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "TSU Student Practice CBT",
  description: "Taraba State University student practice and CBT platform"
};

export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}