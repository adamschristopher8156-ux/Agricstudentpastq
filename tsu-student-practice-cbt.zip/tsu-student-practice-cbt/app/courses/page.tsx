import Link from "next/link";
const courses=[
["TSU-ANS 204","Introduction to Biochemistry"],
["AGR 204","Principles of Animal Production"],
["TSU CPS 204","Introduction to Agricultural Biotechnology"]
];
export default function Courses(){return <><nav className="nav"><b>TSU Student Practice CBT</b><Link href="/">Home</Link></nav><main className="container"><h1>Courses</h1><div className="grid">{courses.map(([code,name])=><div className="card" key={code}><h2>{code}</h2><p>{name}</p><p className="muted">Choose a practice mode and test yourself.</p><Link className="btn" href="/practice">Practice course</Link></div>)}</div></main></>}