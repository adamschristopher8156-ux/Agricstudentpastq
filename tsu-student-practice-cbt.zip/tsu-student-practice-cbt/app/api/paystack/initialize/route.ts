import {NextResponse} from "next/server";
export async function POST(req:Request){
 const body=await req.json(); const secret=process.env.PAYSTACK_SECRET_KEY;
 if(!secret)return NextResponse.json({error:"PAYSTACK_SECRET_KEY is not configured"},{status:500});
 const email=body.email; if(!email)return NextResponse.json({error:"Email required"},{status:400});
 const r=await fetch("https://api.paystack.co/transaction/initialize",{method:"POST",headers:{Authorization:`Bearer ${secret}`,"Content-Type":"application/json"},body:JSON.stringify({email,amount:100000,currency:"NGN",callback_url:`${process.env.NEXT_PUBLIC_SITE_URL}/payment/success`})});
 const data=await r.json(); return NextResponse.json(data,{status:r.ok?200:400});
}