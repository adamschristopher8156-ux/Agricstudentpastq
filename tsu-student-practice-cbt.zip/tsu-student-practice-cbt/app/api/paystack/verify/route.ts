import {NextResponse} from "next/server";
export async function GET(req:Request){
 const reference=new URL(req.url).searchParams.get("reference");
 if(!reference)return NextResponse.json({error:"Missing reference"},{status:400});
 const secret=process.env.PAYSTACK_SECRET_KEY; if(!secret)return NextResponse.json({error:"Missing Paystack secret"},{status:500});
 const r=await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,{headers:{Authorization:`Bearer ${secret}`}});
 const data=await r.json();
 if(!r.ok || data?.data?.status!=="success" || data?.data?.amount!==100000 || data?.data?.currency!=="NGN")return NextResponse.json({error:"Payment not verified",data},{status:400});
 return NextResponse.json({verified:true,reference});
}