# TSU Student Practice CBT

Deployment target: Vercel + Supabase + Paystack.

## Premium
Price is fixed at **₦1,000 (NGN)**.
Paystack amount sent to the API is **100000 kobo**.

## Local setup
1. Install Node.js 20+.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Add Supabase and Paystack credentials.
5. Run `npm run dev`.
6. Open http://localhost:3000.

## Supabase
Run `supabase/schema.sql` in the Supabase SQL editor.

## Vercel
Import this folder as a Git repository, add the same environment variables, and deploy.

## Important production step
The included Paystack initialize/verify routes establish the payment architecture. Before charging real students, connect the payment button to `/api/paystack/initialize`, verify every transaction server-side, record the payment, and create/update the user's subscription only after successful verification. Never expose the Paystack secret or Supabase service-role key in browser code.

## Question bank
The repository includes starter questions. The production question bank should be expanded with the full curated TSU question set and imported through the database/admin workflow before launch.
